public class User {
    //Variables
    private String userName;

    //Constructor
    public User(String userName) {
        this.userName = userName;
    }

    //Getters and Setters

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }


}
